package testvelocidad.tool;

public class tiempo {
    
    private long ms;

    public tiempo() {
        this.ms = 0;
    }

    public long getMs() {
        this.ms = System.currentTimeMillis();
        return ms;
    }
    
}
