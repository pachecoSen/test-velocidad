package testvelocidad;

import java.util.Arrays;
import testvelocidad.peticiones.solicitus;
import testvelocidad.peticiones.tool;

public class testVelocidad {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        solicitus s = new solicitus();
        tool tP = new tool();
        double velDownUP[][] = new double[2][20];
        for(int i=0; i<20; i++){
            String[] testDown = s.testDown();
            int t = testDown[0].length()/1024;
            velDownUP[0][i]=t/Double.valueOf(testDown[1]);
            
            String str = testDown[0];
            String[] testUp = s.testUp(t,str);
            if("1".equals(testUp[0])){
                t = str.length()/1024;
                velDownUP[1][i]=t/Double.valueOf(testUp[1]);
            }
        }
        double[] calcDownUP = tP.calcDownUP(velDownUP[0]);
        Arrays.sort(velDownUP[0]);
        double[] subConjuntoDown = tP.subConjunto(velDownUP[0], calcDownUP[0]);
        subConjuntoDown = tP.invierteArray(subConjuntoDown);
        subConjuntoDown = tP.subConjunto(subConjuntoDown, calcDownUP[1]);
        double pon = (double) 1/subConjuntoDown.length;
        double vel = 0;
        for(int y=0;y < subConjuntoDown.length;y++)
            vel += subConjuntoDown[y]*pon;
        vel /= 1024; //Mbps
        vel *= 8; //Mbps
        
        System.out.println("Descarga : "+vel+" Mbps");
        
        calcDownUP = tP.calcDownUP(velDownUP[1]);
        Arrays.sort(velDownUP[1]);
        subConjuntoDown = tP.subConjunto(velDownUP[1], calcDownUP[0]);
        subConjuntoDown = tP.invierteArray(subConjuntoDown);
        subConjuntoDown = tP.subConjunto(subConjuntoDown, calcDownUP[1]);
        pon = (double) 1/subConjuntoDown.length;
        vel = 0;
        for(int y=0;y < subConjuntoDown.length;y++)
            vel += subConjuntoDown[y]*pon;
        vel /= 1024; //Mb/s
        vel *= 8; //Mbps
        System.out.println("Tranferencia : "+vel+" Mbps");
    }
    
}
