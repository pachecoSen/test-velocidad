package testvelocidad.peticiones;

public class tool {
    
    private double sumArray;
    private final double cal[];
    private boolean est;
    private double sData[];

    public tool() {
        this.est = true;
        this.cal = new double[2];
        this.sumArray = 0;
    }
    public double[] calcDownUP(double data[]){
        double sumaArray = this.sumaArray(data);
        cal[0] = 0.3*sumaArray;
        cal[1] = 0.1*sumaArray;
        
        return this.cal;
    }
    
    public double[] subConjunto(double data[],double limite){
        this.restEst();
        int i = 0,temp = -1;
        double sum=0,optA = 0,optB = 0;
	while (this.isEst()) {
            sum+=data[i];
            if(sum>limite){
                if((i-1) > -1){
                    optA = limite - (sum-data[i-1]);
		    optB = sum - limite;
                    temp = (optA <= optB) ? i-- : i;
                }
                this.setEst(false);
            }
            else
                i++;
        }
        if(temp>-1){
            int tamaño=data.length-temp;
            this.sData = new double[tamaño];
            for(int y = 0; y<tamaño;y++)
                this.sData[y]=data[temp+y];
        }
        else
            this.sData = data.clone();
        
        return sData;
    }
    
    public double[] invierteArray(double data[]){
        int tamano = data.length;
        this.sData = new double[tamano];
        for(int y=0;y<tamano;y++){
            this.sData[y] = data[(tamano-y-1)];
        }
        return this.sData;
    }
    
    private double sumaArray(double data[]){
        this.resetSumArray();
        for(int i=0;i<data.length;i++)
            this.setSumArray(data[i]);
        return this.getSumArray();
    }

    private double getSumArray() { return sumArray; }

    private void setSumArray(double sumArray) { this.sumArray += sumArray; }
    
    private void resetSumArray(){ this.sumArray = 0; }

    private boolean isEst() { return est; }

    private void setEst(boolean est) { this.est = est; }
    
    private void restEst(){ this.setEst(true); }
    
}
