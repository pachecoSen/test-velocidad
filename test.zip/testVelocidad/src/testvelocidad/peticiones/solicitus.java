package testvelocidad.peticiones;

import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.Random;
import java.util.logging.Level;
import java.util.logging.Logger;
import testvelocidad.tool.tiempo;

public class solicitus {
    
    private final String[] arch;
    private final String uri;
    private final String post;
    private final Random rn;
    private final String get[];
    private final tiempo t;
    private long start;
    private long end;
    private double tExe;
    private HttpURLConnection html;
    private final String USER_AGENT;
    private DataOutputStream wr;
    private final StringBuilder result;
    
    public solicitus() {
        this.result = new StringBuilder();
        this.USER_AGENT = "Mozilla/5.0";
        this.tExe = 0;
        this.get = new String[2];
        this.end = 0;
        this.start = 0;
        this.t = new tiempo();
        this.rn = new Random();
        //this.uri = "http://172.16.6.90/monitoreo/Api/src/rutas/files/";
        this.uri = "http://rubikode.com/";
        this.post = "http://172.16.6.90/monitoreo/Api/public/ping/up";
        this.arch = new String[]{"down2", "down1", "down0", "down00", "down000", "down0000"};
    }
    
    public String[] testDown(){
        try {
            this.resetGet();
            int index = rn.nextInt(this.arch.length);
            this.setStart(this.t.getMs());
            URL url = new URL(this.uri+this.arch[index]);
            try (BufferedReader in = new BufferedReader(new InputStreamReader(url.openStream()))) {
                this.setEnd(this.t.getMs());
                this.setGet(String.valueOf(this.gettExe()),1);
                String temp;
                while ((temp = in.readLine()) != null)
                    this.setGet(temp,0);
            }
        }
        catch (IOException ex) { Logger.getLogger(solicitus.class.getName()).log(Level.SEVERE, null, ex); }
        
        return this.getGet();
    }
    
    public String[] testUp(int size,String str){
        try {
            this.resetGet();
            this.setStart(this.t.getMs());
            URL url = new URL(this.getPost());
            this.html = (HttpURLConnection) url.openConnection();
            this.html.setRequestMethod("POST");
            this.html.setRequestProperty("User-Agent", USER_AGENT);
            this.html.setRequestProperty("Accept-Language", "en-US,en;q=0.5");
            String urlParameters = "t="+size+"&c="+str;
            this.html.setDoOutput(true);
            this.wr = new DataOutputStream(this.html.getOutputStream());
            this.wr.writeBytes(urlParameters);
            this.wr.flush();
            this.wr.close();
            int responseCode = this.html.getResponseCode();
            if(responseCode == 200){
                this.setEnd(this.t.getMs());
                this.setGet(String.valueOf(this.gettExe()),1);
                StringBuffer response;
                try (BufferedReader in = new BufferedReader( new InputStreamReader(this.html.getInputStream()))) {
                    String inputLine;
                    response = new StringBuffer();
                    while ((inputLine = in.readLine()) != null)
                        response.append(inputLine);
                }
                this.setGet(response.toString(),0);
            }
            this.html.disconnect();
            
        } catch (MalformedURLException ex) {
            Logger.getLogger(solicitus.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(solicitus.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        return this.getGet();
    }
    
    private long getStart() { return start; }

    private void setStart(long start) { this.start = start; }

    private long getEnd() { return end; }

    private void setEnd(long end) { this.end = end; }

    private double gettExe() {
        this.tExe = Integer.parseInt((this.getEnd()-this.getStart())+"");
        return (tExe <= 0) ? 0.001 : tExe/1000;
    }
    
    private void resetGet(){
        this.get[0] = "";
        this.get[1] = null;
    }

    public String[] getGet() { return get; }

    public void setGet(String valor,int index) {
        if(index==0)
            this.get[0] += valor;
        else
            this.get[1] = valor;
    }

    public String getPost() { return post; }
    
}
